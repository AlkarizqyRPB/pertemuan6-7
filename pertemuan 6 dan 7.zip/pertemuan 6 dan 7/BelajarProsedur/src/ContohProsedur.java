/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author hp
 */
public class ContohProsedur {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
    Manusia joko = new Manusia();
    joko.nama = "Joko Tingkir";
    joko.JK = "Lakik";
    joko.alamat = "Garut";
    
    Manusia kojo = new Manusia();
    kojo.nama = "Kojo";
    kojo.JK = "Ciwi";
    kojo.alamat = "Garut";
    
    joko.TampilanInformasi();
    kojo.TampilanInformasi();
    }
    
}
