/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author hp
 */
public class ContohSapa {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
    Manusia Bukan = new Manusia();
    Bukan.nama = "Bukan";
    
    Bukan.sapa ("Budi");
    
    Bukan.sapa ("Didi");
    
    Bukan.sapa ("Badi");
    }
    
}
