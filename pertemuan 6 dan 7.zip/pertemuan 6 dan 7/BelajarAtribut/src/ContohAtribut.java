/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author hp
 */
public class ContohAtribut {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        Orang Alkarizqy = new Orang();
        Alkarizqy.nama = "Alkarizqy";
        Alkarizqy.alamat = "Sumedang";
        Alkarizqy.umur = 19;
        Alkarizqy.menikah =false;
        
        Orang Restu = new Orang();
        Restu.nama = "Restu";
        Restu.alamat = "Sumedang";
        Restu.umur = 20;
        Restu.menikah =false;
     
        System.out.println(Alkarizqy.nama);
        System.out.println(Alkarizqy.alamat);
        System.out.println(Alkarizqy.umur);
        System.out.println(Alkarizqy.menikah);
        System.out.println(Restu.nama);
        System.out.println(Restu.alamat);
        System.out.println(Restu.umur);
        System.out.println(Restu.menikah);
    }
    
}
