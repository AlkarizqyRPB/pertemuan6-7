/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author akoh
 */
public class ContohThis {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
      Orang bukan = new Orang();
      bukan.ubahNama("Bukan Orang");
      
      System.out.println(bukan.nama);
        
      System.out.println(bukan.nama);
    }
    
}
